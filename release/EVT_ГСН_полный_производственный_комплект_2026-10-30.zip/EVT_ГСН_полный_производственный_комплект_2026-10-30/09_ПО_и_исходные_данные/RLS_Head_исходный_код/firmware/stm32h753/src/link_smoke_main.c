#include "rls/hil_r1.h"
#include "rls/hil_r2.h"
#include "rls/hil_r2_evidence.h"
#include "rls/sys_err.h"
#include "rls/targetstate_uncertainty.h"
#include "rls/targetstate_error_ledger.h"
#include "rls/time_service.h"
#include "rls/radar_link.h"
#include "rls/carrier_health.h"
#include "rls/measurement_session.h"
#include "rls/evidence_export.h"
#include "rls/capture_router.h"
#include "rls/config_lock.h"
#include "rls/gnss_service.h"
#include "rls/imu_service.h"
#include "stm32h753_memory.h"

#include <stddef.h>
#include <stdint.h>

#define DMA_ALIGN __attribute__((aligned(32)))

static HilRuntime g_hil_runtime
    __attribute__((section(".dtcm_bss"), aligned(8)));

static uint8_t g_hil_request[
    HIL_HEADER_WIRE_SIZE +
    HIL_DETECTION_WIRE_SIZE +
    HIL_CRC_WIRE_SIZE]
    __attribute__((section(".dma_rx"))) DMA_ALIGN;

static uint8_t g_targetstate_response[TARGETSTATE_PACKET_SIZE]
    __attribute__((section(".dma_tx"))) DMA_ALIGN;

static volatile uint32_t g_smoke_status
    __attribute__((section(".sram4_status"), aligned(32)));

static volatile uint32_t g_smoke_response_len
    __attribute__((section(".sram4_status"), aligned(4)));

int main(void)
{
    size_t response_len = 0u;

    hil_runtime_init(
        &g_hil_runtime,
        0x524C5301u,
        0x00000001u);

    /*
     * The request buffer is intentionally not made into a valid frame here.
     * This target is a cross-link/placement gate, not a hardware execution
     * image. Calling the full runtime keeps the production HIL-R1 call graph
     * reachable in the Cortex-M7 ELF so link/memory evidence reflects the
     * actual sensing pipeline.
     */
    const HilRuntimeResult result =
        hil_runtime_process_packet(
            &g_hil_runtime,
            g_hil_request,
            sizeof(g_hil_request),
            1u,
            2u,
            g_targetstate_response,
            sizeof(g_targetstate_response),
            &response_len);

    const float timing_error_m =
        hil_r2_timing_position_error_m(
            300.0f,
            3.14159265358979323846f,
            0.001f);

    const HilR2Vec3f sensor_velocity =
        hil_r2_lever_arm_velocity(
            (HilR2Vec3f){0.0f, 0.0f, 1.5707963267948966f},
            (HilR2Vec3f){0.2f, 0.0f, 0.0f});

    SysErrMat3f timing_cov;

    const bool timing_cov_ok =
        sys_err_timing_position_covariance(
            (HilR2Vec3f){300.0f, 0.0f, 0.0f},
            (HilR2Vec3f){0.0f, 0.0f, 0.0f},
            (HilR2Vec3f){0.0f, 0.0f, 3.14159265358979323846f},
            0.0005f,
            &timing_cov);

    const float timing_rms =
        timing_cov_ok
            ? sys_err_position_rms(&timing_cov)
            : 0.0f;

    TargetStateV1 synthetic_state = {0};
    synthetic_state.relative_position_m[0] = 300.0f;
    synthetic_state.position_cov_ut[0] = 0.25f;
    synthetic_state.position_cov_ut[3] = 0.04f;
    synthetic_state.position_cov_ut[5] = 0.09f;

    TargetStateSysErrInputs sys_err_inputs = {0};
    sys_err_inputs.angular_rate_rad_s.z = 3.14159265358979323846f;
    sys_err_inputs.timestamp_sigma_s = 0.0005f;

    TargetStateSysErrResult sys_err_result;
    const bool targetstate_syserr_ok =
        targetstate_apply_sys_err(
            &synthetic_state,
            &sys_err_inputs,
            &sys_err_result);

    HilR2Evidence runtime_evidence;
    hil_r2_evidence_reset(&runtime_evidence);

    (void)hil_r2_evidence_record_radar_imu(
        &runtime_evidence,
        100.0f);

    (void)hil_r2_evidence_record_pps(
        &runtime_evidence,
        20.0f);

    (void)hil_r2_evidence_update_holdover(
        &runtime_evidence,
        120.0f);

    TimeService time_service;
    const bool time_init_ok =
        time_service_init(
            &time_service,
            0.25f,
            2.0f,
            100.0f);

    const TimeObserveResult pps1 =
        time_init_ok
            ? time_service_observe_pps(
                &time_service,
                1000000u,
                10000000)
            : TIME_OBSERVE_REJECTED_ARGUMENT;

    const TimeObserveResult pps2 =
        time_init_ok
            ? time_service_observe_pps(
                &time_service,
                2000000u,
                11000002)
            : TIME_OBSERVE_REJECTED_ARGUMENT;

    int64_t disciplined_time = 0;

    const bool time_map_ok =
        time_init_ok &&
        time_service_map_us(
            &time_service,
            2500000u,
            &disciplined_time);

    rls_radar_link_msg_t radar_msg = {
        .version = RLS_RADAR_LINK_VERSION,
        .type = RLS_RADAR_MSG_FRAME_META,
        .status_flags = 0u,
        .sequence = 1u,
        .radar_time_us = 2500000u,
        .config_crc32 = 0x12345678u,
        .temperature_cdeg = 2500,
        .measurement_count = 0u,
    };
    uint8_t radar_wire[RLS_RADAR_LINK_WIRE_SIZE] = {0};
    const bool radar_link_ok =
        rls_radar_link_encode(
            &radar_msg,
            radar_wire,
            sizeof(radar_wire)) == 0;

    rls_carrier_health_state_t carrier_health;
    rls_carrier_health_report_t carrier_report;
    const rls_carrier_health_limits_t carrier_limits = {
        .radar_timeout_us = 100000u,
        .gnss_pps_timeout_us = 1500000u,
        .imu_timeout_us = 20000u,
    };

    rls_carrier_health_init(&carrier_health);
    rls_carrier_health_note_radar_ref(
        &carrier_health,
        2400000u);
    rls_carrier_health_note_gnss_pps(
        &carrier_health,
        2000000u);
    rls_carrier_health_note_imu_drdy(
        &carrier_health,
        2495000u);

    const bool carrier_health_ok =
        rls_carrier_health_evaluate(
            &carrier_health,
            &carrier_limits,
            2500000u,
            &carrier_report) == 0;

    rls_measurement_session_t measurement_session;
    rls_measurement_session_init(&measurement_session);
    const bool measurement_session_ok =
        rls_measurement_session_arm(
            &measurement_session,
            1u,
            radar_msg.config_crc32,
            2400000u)
        && rls_measurement_session_start(
            &measurement_session,
            2450000u)
        && rls_measurement_session_note_radar(
            &measurement_session)
        && rls_measurement_session_close(
            &measurement_session,
            2500000u);

    rls_evidence_export_record_t evidence_record;
    uint8_t evidence_wire[RLS_EVIDENCE_EXPORT_WIRE_SIZE] = {0};
    const bool evidence_export_ok =
        measurement_session_ok
        && rls_evidence_export_build(
            &measurement_session,
            &time_service,
            &carrier_report,
            2500000u,
            &evidence_record) == 0
        && rls_evidence_export_encode(
            &evidence_record,
            evidence_wire,
            sizeof(evidence_wire)) == 0;

    rls_capture_router_t capture_router;
    rls_capture_event_t capture_event;
    rls_capture_router_init(&capture_router);
    const bool capture_router_ok =
        rls_capture_router_push(
            &capture_router,
            RLS_CAPTURE_RADAR_REF,
            2500000u)
        && rls_capture_router_pop(
            &capture_router,
            &capture_event);

    static const uint8_t carrier_config[] = {
        0x52u, 0x4Cu, 0x53u, 0x01u
    };
    rls_config_lock_t config_lock;
    rls_config_lock_init(&config_lock);
    const bool config_lock_ok =
        rls_config_lock_stage(
            &config_lock,
            1u,
            carrier_config,
            sizeof(carrier_config))
        && rls_config_lock_commit(
            &config_lock)
        && rls_config_lock_verify(
            &config_lock,
            1u,
            carrier_config,
            sizeof(carrier_config));

    rls_gnss_service_t gnss_service;
    rls_gnss_report_t gnss_report;
    const rls_gnss_limits_t gnss_limits = {
        .uart_timeout_us = 2000000u,
        .pps_timeout_us = 1500000u,
    };
    rls_gnss_service_init(&gnss_service);
    rls_gnss_service_note_uart(
        &gnss_service,
        2400000u);
    rls_gnss_service_note_pps(
        &gnss_service,
        2000000u);
    rls_gnss_service_update_quality(
        &gnss_service,
        true,
        true,
        false,
        false);
    const bool gnss_service_ok =
        rls_gnss_service_evaluate(
            &gnss_service,
            &gnss_limits,
            2500000u,
            &gnss_report) == 0
        && gnss_report.healthy;

    rls_imu_service_t imu_service;
    rls_imu_report_t imu_report;
    const rls_imu_limits_t imu_limits = {
        .sample_timeout_us = 20000u,
    };
    rls_imu_service_init(&imu_service);
    uint32_t imu_sequence = 0u;
    const bool imu_service_ok =
        rls_imu_service_note_drdy(
            &imu_service,
            2495000u,
            &imu_sequence)
        && imu_sequence == 0u
        && rls_imu_service_begin_transfer(
            &imu_service)
        && rls_imu_service_complete_transfer(
            &imu_service,
            true)
        && rls_imu_service_evaluate(
            &imu_service,
            &imu_limits,
            2500000u,
            &imu_report) == 0
        && imu_report.fresh;

    TargetStateErrorLedger error_ledger;
    const bool ledger_ok =
        targetstate_syserr_ok &&
        targetstate_build_error_ledger(
            &sys_err_result,
            &error_ledger);

    g_smoke_status =
        (uint32_t)result ^
        (uint32_t)g_stm32h753_mpu_plan_count ^
        (uint32_t)(timing_error_m * 1000.0f) ^
        (uint32_t)(sensor_velocity.y * 1000.0f) ^
        (uint32_t)(timing_rms * 1000.0f) ^
        (targetstate_syserr_ok
            ? (uint32_t)(sys_err_result.total_position_rms_m * 1000.0f)
            : 0u) ^
        (ledger_ok
            ? (uint32_t)error_ledger.dominant_overall_source
            : 0u) ^
        (uint32_t)runtime_evidence.radar_imu_us.count ^
        (uint32_t)runtime_evidence.pps_us.count ^
        (uint32_t)pps1 ^
        ((uint32_t)pps2 << 4) ^
        (time_map_ok
            ? (uint32_t)(disciplined_time & 0xFFFF)
            : 0u) ^
        (radar_link_ok
            ? (uint32_t)radar_wire[0]
            : 0u) ^
        (carrier_health_ok
            ? carrier_report.fault_flags
            : UINT32_C(0x80000000)) ^
        (measurement_session_ok
            ? measurement_session.session_id
            : UINT32_C(0x20000000)) ^
        (evidence_export_ok
            ? (uint32_t)evidence_wire[0]
            : UINT32_C(0x10000000)) ^
        (capture_router_ok
            ? capture_event.sequence
            : UINT32_C(0x40000000)) ^
        (config_lock_ok
            ? config_lock.crc32
            : UINT32_C(0x04000000)) ^
        (gnss_service_ok
            ? gnss_report.flags
            : UINT32_C(0x02000000)) ^
        (imu_service_ok
            ? imu_report.completed_samples
            : UINT32_C(0x01000000));

    g_smoke_response_len =
        (uint32_t)response_len;

    for (;;) {
        __asm volatile ("wfi");
    }
}
