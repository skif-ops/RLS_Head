﻿@echo off
start "" "%~dp0EVT_GSN_Digital_Twin.exe" --auto-start --port 9750
timeout /t 1 /nobreak >nul
start "" "%~dp0EVT_GSN_Visualizer.exe" --tcp --tcp-host 127.0.0.1 --tcp-port 9750
