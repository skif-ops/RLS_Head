import inspect
import sys
from pathlib import Path


SOURCE_ROOT = Path(__file__).resolve().parents[2]
if str(SOURCE_ROOT) not in sys.path:
    sys.path.insert(0, str(SOURCE_ROOT))

import test_protocol


def main():
    tests = [
        (name, function)
        for name, function in inspect.getmembers(test_protocol, inspect.isfunction)
        if name.startswith("test_")
    ]
    for name, function in tests:
        function()
        print(f"{name} PASS")
    print(f"PYTHON PROTOCOL SUITE PASS ({len(tests)} tests)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
