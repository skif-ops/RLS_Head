import ast
import hashlib
import importlib
import json
import re
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parent
EMBEDDED_PACKAGE = ROOT.parent
PACKAGE = (
    EMBEDDED_PACKAGE
    if (EMBEDDED_PACKAGE / "03_Машинные_контракты" / "targetstate_v1_contract.json").exists()
    else ROOT / "package"
)
CONTRACT = PACKAGE / "03_Машинные_контракты" / "targetstate_v1_contract.json"
HEADER = PACKAGE / "02_Исходный_код" / "include" / "rls" / "hil_r1.h"
PYTHON_CODEC = PACKAGE / "02_Исходный_код" / "tools" / "hil_host" / "targetstate.py"
PROTOCOL = PACKAGE / "02_Исходный_код" / "tools" / "hil_host" / "protocol.py"


def check(condition, message, findings):
    if not condition:
        findings.append(message)


def decoder_keys(path):
    tree = ast.parse(path.read_text(encoding="utf-8"))
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "decode_targetstate_v1":
            for child in ast.walk(node):
                if isinstance(child, ast.Return) and isinstance(child.value, ast.Dict):
                    return {
                        key.value
                        for key in child.value.keys
                        if isinstance(key, ast.Constant) and isinstance(key.value, str)
                    }
    return set()


def main():
    findings = []
    contract = json.loads(CONTRACT.read_text(encoding="utf-8"))
    fields = contract["wire_fields"]
    names = [field["name"] for field in fields]

    check(contract["direction"] == "device_to_host", "contract direction is not device_to_host", findings)
    check(contract["transport"]["packet_size_bytes"] == 200, "packet size is not 200", findings)
    check(len(contract["message_types"]) == 1, "more than one message type is declared", findings)
    if contract["message_types"]:
        message = contract["message_types"][0]
        check(message == {"value": 1, "name": "TARGET_STATE", "direction": "device_to_host"}, "message type is not the single TARGET_STATE telemetry message", findings)

    expected_offset = 0
    for field in fields:
        check(field["offset"] == expected_offset, f"wire gap or overlap before {field['name']}", findings)
        expected_offset = field["offset"] + field["size"]
    check(expected_offset == 200, f"wire layout ends at {expected_offset}, expected 200", findings)

    banned = ("lead_point", "intercept", "guidance", "actuator", "setpoint", "command")
    for name in names:
        lowered = name.lower()
        check(not any(term in lowered for term in banned), f"prohibited field name: {name}", findings)

    header_text = HEADER.read_text(encoding="utf-8")
    check("#define TARGETSTATE_MSG_STATE 1u" in header_text, "TARGETSTATE state message constant is missing", findings)
    check(not re.search(r"TARGETSTATE_MSG_(COMMAND|GUIDANCE|CONTROL|SETPOINT)", header_text), "command message constant exists in C header", findings)
    check("#define TARGETSTATE_PACKET_SIZE 200u" in header_text, "C packet size does not declare 200 bytes", findings)

    keys = decoder_keys(PYTHON_CODEC)
    expected_decoder_keys = {
        "protocol_major", "protocol_minor", "message_type", "header_flags", "sequence", "source_id", "boot_id",
        "measurement_timestamp_us", "state_timestamp_us", "publish_timestamp_us", "track_id", "coordinate_frame",
        "track_state", "motion_model", "reserved0", "validity_mask", "range_m", "range_rate_m_s", "azimuth_deg",
        "elevation_deg", "position_m", "velocity_m_s", "acceleration_m_s2", "snr_db", "track_quality", "confidence",
        "measurement_age_ms", "position_cov_ut", "velocity_cov_ut", "timestamp_uncertainty_us", "radar_status",
        "fusion_status", "track_flags", "reserved1"
    }
    check(keys == expected_decoder_keys, "Python decoder key set differs from the declared telemetry contract", findings)

    package_root = str((PACKAGE / "02_Исходный_код").resolve())
    if package_root not in sys.path:
        sys.path.insert(0, package_root)
    protocol = importlib.import_module("tools.hil_host.protocol")
    codec = importlib.import_module("tools.hil_host.targetstate")
    packet = codec.build_synthetic_targetstate_packet()
    decoded = codec.decode_targetstate_v1(packet)
    check(len(packet) == 200, "synthetic packet is not 200 bytes", findings)
    check(decoded["message_type"] == 1, "synthetic packet is not TARGET_STATE", findings)
    check(protocol.crc32c(packet[:196]) == int.from_bytes(packet[196:200], "little"), "synthetic CRC32C mismatch", findings)
    corrupt = bytearray(packet)
    corrupt[60] ^= 0x01
    try:
        codec.decode_targetstate_v1(bytes(corrupt))
        findings.append("corrupted packet was accepted")
    except ValueError:
        pass

    packet_path = PACKAGE / "04_Проверки" / "targetstate_example.bin"
    packet_path.write_bytes(packet)

    result = {
        "schema": "tracking-only-interface-verification-v1",
        "status": "PASS" if not findings else "FAIL",
        "checks": {
            "single_device_to_host_message": len(contract["message_types"]) == 1,
            "wire_layout_bytes": expected_offset,
            "field_count": len(fields),
            "python_decoder_key_count": len(keys),
            "synthetic_packet_bytes": len(packet),
            "crc_corruption_rejected": "corrupted packet was accepted" not in findings,
            "prohibited_output_fields_found": [name for name in names if any(term in name.lower() for term in banned)]
        },
        "findings": findings,
        "source_hashes": {
            str(path.relative_to(PACKAGE)).replace("\\", "/"): hashlib.sha256(path.read_bytes()).hexdigest()
            for path in (CONTRACT, HEADER, PYTHON_CODEC, PROTOCOL)
        },
        "limitations": [
            "No AWR2944P application image is included or verified.",
            "No hardware UART or CAN-FD bench test is represented by this result.",
            "Production authority remains NOT_AUTHORIZED."
        ]
    }
    output = PACKAGE / "04_Проверки" / "Проверка_телеметрического_интерфейса.json"
    output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if not findings else 1


if __name__ == "__main__":
    raise SystemExit(main())
