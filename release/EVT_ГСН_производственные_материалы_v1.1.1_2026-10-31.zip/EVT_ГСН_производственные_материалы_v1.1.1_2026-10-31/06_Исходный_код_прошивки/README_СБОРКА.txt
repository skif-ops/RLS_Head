﻿Корень сборки содержит CMakeLists.txt.
Целевая конфигурация: config/evt_carrier_firmware_v1.json.
Поддерживаемый target: STM32H753IIT6, конфигурация Release.
Скрипт формального выпуска: firmware/stm32h753/tools/build_release.ps1.
