﻿Откройте EVT_SYS_CARRIER.PrjPcb в Altium Designer.
В папке находятся актуальные SchDoc, PcbDoc, библиотеки, OutJob и сгенерированные выходные файлы.
